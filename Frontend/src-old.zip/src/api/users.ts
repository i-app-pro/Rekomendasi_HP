// src/api/users.ts
import axios from "../lib/axios";

export const userService = {
  getAll: () => axios.get("/api/users"),
  getById: (id: string) => axios.get(`/api/users/${id}`),
  create: (data: any) => axios.post("/api/users", data),
  update: (id: string, data: any) => axios.put(`/api/users/${id}`, data),
  delete: (id: string) => axios.delete(`/api/users/${id}`),
};