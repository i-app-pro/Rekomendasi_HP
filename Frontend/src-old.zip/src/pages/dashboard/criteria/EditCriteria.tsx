import React, { useState, useEffect } from 'react';
import { type CriteriaData } from './CreateCriteria';

interface EditCriteriaProps {
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (data: CriteriaData) => void;
  criteriaData: CriteriaData | null;
}

export default function EditCriteria({ isOpen, onClose, onUpdate, criteriaData }: EditCriteriaProps) {
  const [formData, setFormData] = useState<CriteriaData>({ nama: '', atribut: 'Benefit' });

  // Sinkronkan data saat modal edit terbuka
  useEffect(() => {
    if (criteriaData) {
      setFormData(criteriaData);
    }
  }, [criteriaData, isOpen]);

  if (!isOpen || !criteriaData) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(formData); 
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex justify-center items-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        <div className="bg-[#1e2530] px-6 py-4 flex justify-between items-center">
          <h2 className="text-white font-bold text-lg">Edit Data Kriteria</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors cursor-pointer">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-4">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Nama Kriteria</label>
            <input 
              type="text" 
              name="nama" 
              value={formData.nama} 
              onChange={handleChange} 
              required
              className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Atribut</label>
            <select 
              name="atribut" 
              value={formData.atribut} 
              onChange={handleChange} 
              className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-white outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="Benefit">Benefit (Keuntungan)</option>
              <option value="Cost">Cost (Biaya)</option>
            </select>
          </div>

          <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-slate-100">
            <button type="button" onClick={onClose} className="px-5 py-2 rounded-lg font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 cursor-pointer">Batal</button>
            <button type="submit" className="px-5 py-2 rounded-lg font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-sm cursor-pointer">Update</button>
          </div>
        </form>
      </div>
    </div>
  );
}